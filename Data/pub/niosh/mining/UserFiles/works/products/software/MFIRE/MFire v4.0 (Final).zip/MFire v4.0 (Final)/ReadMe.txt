
MFire 4.0 README

Welcome to MFire Version 4.0 

------------------------------------------------------------------------------------------------------------
To install MFire run the "MFire Setup.exe" install program, and follow the instructions.

			
------------------------------------------------------------------------------------------------------------

RELEASE NOTES:

Build 4.0.2.0 (07/24/2020)
�	Final build for 4.0 release

Build 4.0.0.2 (11/20/2019)
�	Remove ChangeFire Event 

Build 4.0.0.1 (10/16/2019)
�	T square fix

Build 4.0.0.0 (8/2/2019)

�	Add T-Squared fire algorithm
		Including properties of the fire (Tlead, Tmax, Tsteady, Tdecay, Qmax, FumeProConstant)
	
�	Add Heat Release Rate Curve input lines to config file (see example files)

�	Add SmokeRollback calculations and indicator
		Including Properties: HasSmokeRollback, LengthOfRollback

�	Add to config file ability to define a FireType (allows setting which type of fire calculation: Original, HRR Curve, T-Squared)

�	Add ChangeFire event
�	Add x, y coordinates to junctions (and corresponding config files)
�	Update text config file to handle comments (see new example config files)
�	BUG - Fixed a bug which causes out of boundary index compiling error when TransientState is set to 1
�	BUG - englarge the size of arrays from +10 to +100 to let a case run through.
�	Update documentation


MFire does not contain any proprietary, third-party software.



------------------------------------------------------------------------------------------------------------
MODEL CERTIFICATION

Scan date: 7/24/2020. This product has been scanned for known viruses and other malicious code with 
the following product(s) (Windows Defender Security Center, definitions updated 7/24/2020), which were the 
most current commercially available versions as of the date of scanning indicated above, and is certified to 
be free of known malicious code, as long as the package seal has not been broken. However, we encourage you 
to scan it again before you use it. If there is a problem with this product, please contact the NIOSH Mining 
Program via email at (mining@cdc.gov). 

------------------------------------------------------------------------------------------------------------
Disclaimer of Liability

Mention of any company or product does not constitute endorsement by the National Institute for Occupational 
Safety and Health (NIOSH). In addition, citations to Web sites external to NIOSH do not constitute NIOSH 
endorsement of the sponsoring organizations or their programs or products. Furthermore, NIOSH is not 
responsible for the content of these Web sites. All Web addresses referenced in this document were accessible 
as of the publication date.
 
This NIOSH-developed software is provided "AS IS" without warranty of any kind including express or implied 
warranties of merchantability or fitness for a particular purpose. By acceptance and use of this software, 
which is conveyed to the user without consideration by NIOSH, the user expressly waives any and all claims for 
damage and/or suits for personal injury or property damage resulting from any direct, indirect, incidental, 
special or consequential damages, or damages for loss of profits, revenue, data or property use, incurred by 
you or any third party, whether in an action in contract or tort, arising from your access to, or use of, this 
software in whole or in part.

No further development or upgrades for this software is planned. Any questions concerning this product can be 
directed to the NIOSH Mining Program via email at mining@cdc.gov.

------------------------------------------------------------------------------------------------------------
TERMS OF USE

Further technical information on the derivation, scope, limitations, and use of MFire can be found in 
the Help file included with the program.
